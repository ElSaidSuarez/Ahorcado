
const $bienvenido = document.getElementById("bienvenido")
const $buttonEmpezar = document.getElementById("empezar")
const $contentGame = document.getElementById("content-game")

const $agregarPalabras = document.getElementById("div-agregar-palabras")
const $formAgregarPalabras = document.getElementById("form-agregar-palabras")
const $input = document.getElementById("input")
const $error = document.getElementById("error")
const $buttonAgregarPalabra = document.getElementById("button-agregar-palabras")
const $buttonVolverAJugar = document.getElementById("volver-a-iniciar")

const $letrasADescubrir = document.getElementById("letras-a-descubrir")
const $letrasUtilizadas = document.getElementById("letrasUtilizadas")
const $errores = document.getElementById("errores")
const $teclado = document.getElementById("teclado")
const $imagen = document.getElementById("img")


let palabraSeleccionada;
let letrasUsadas;
let errores;
let aciertos;

const endGame = () => {
    document.removeEventListener("keydown",handleKeydown)

    if (errores === 6) {
        Swal.fire({
            title: '<span>Fallaste</span>',
            text: `La palabra era: ${palabraSeleccionada.join("")}`,
            icon: 'error',
            showCloseButton: false,
            showConfirmButton: true,
            confirmButtonText:"Reintentar",
            confirmButtonAriaLabel:"Reintentar",
            confirmButtonColor: "#000",
            allowOutsideClick:false,
            allowEscapeKey:false,
            allowEnterKey:false,
            customClass:{
                title:"span-swal",
                confirmButton:"close-swal",
                htmlContainer: "text-swal",
            }
        })
        const $reintentar = document.querySelector(".swal2-confirm")
        $reintentar.addEventListener("click",start)
    } else{
        //si ganamos el juego
        //entonces mostramos un modal con la libreria sweetAlert
        Swal.fire({
            title: '<span>Felicidades Ganaste</span>',
            text: `La palabra era: ${palabraSeleccionada.join("")}`,
            icon: 'success',
            showCloseButton: false,
            showConfirmButton: true,
            confirmButtonText:"Volver a jugar",
            confirmButtonAriaLabel:"Volver a jugar",
            confirmButtonColor: "#000",
            allowOutsideClick:false,
            allowEscapeKey:false,
            allowEnterKey:false,
            customClass:{
                title:"span-swal",
                confirmButton:"close-swal",
                htmlContainer: "text-swal",
            }
        })
        const $volverAJugar = document.querySelector(".swal2-confirm")
        $volverAJugar.addEventListener("click",start)
    }
    
}



const cambiarImagen = () => {
    //cambiar la imagen por cada error
    return $imagen.setAttribute("src",`img/ahorcado-${errores}.png`)
}

const letraIncorrecta = () => {
    //aumentamos los errores
    errores++
    $errores.textContent = `Llevas ${errores} intento`
    //funcion cambiarImagen 
    cambiarImagen()

    //intentos fallidos
    //si los errores es igual a 6 errores entonces terminamos el juego
    if (errores === 6) endGame()
}


const letraCorrecta = (letra) => {
    const { children } = $letrasADescubrir
    //el bucle se va a cumpler hasta que la condición sea falsa
    for (let i = 0; i < children.length; i++) {
        //comparamos si la letra del array es igual a la letra que viene por parametro
        if (children[i].innerText === letra ) {
            //aca lo que hace es quitarle la clase hidden para que se muestre la letra
            children[i].classList.toggle("hidden")
            //y aumentamos los aciertos
            aciertos++
        }
    }
    if (aciertos === palabraSeleccionada.length) {
        endGame()
        palabras = palabras.filter(ele => ele !== palabraSeleccionada.join(""))
    }
}

const agregarLetras = (letter) => {
    
    const letterElement = document.createElement("span")
    letterElement.innerHTML = letter
    
    $letrasUtilizadas.appendChild(letterElement)
    letrasUsadas.push(letter)
}

const letraIngresada = (letra) =>{
    
    if (palabraSeleccionada.includes(letra)) {
        
    letraCorrecta(letra)
    } else{

        letraIncorrecta()
    }

    agregarLetras(letra)
}

const handleKeydown = (e) => {

    let letraPresionada = e.key.toUpperCase()

    if(letraPresionada.match(/^[a-zñ]$/i) && !letrasUsadas.includes(letraPresionada)){

        letraIngresada(letraPresionada)
    }

    const { children } = $teclado
    for (let i = 0; i < children.length; i++) {
    
        if (children[i].innerText === letraPresionada) {

            children[i].style.width = "3.45em"
            children[i].style.height = "3.45em"
            children[i].style.opacity = "0.6"
        }
    }
}

const pintarPalabra = () => {

    palabraSeleccionada.forEach(letra => {

        const span = document.createElement("span")
        span.textContent = letra.toUpperCase()

        span.classList.add("letra")
        span.classList.add("hidden")

        $letrasADescubrir.appendChild(span)
    });
}

const seleccionDeLaPalabra = () => {
    const palabraRandom = palabras[Math.floor(Math.random() * palabras.length)].toUpperCase()
    palabraSeleccionada = palabraRandom.split("")
}

function start(){

    letrasUsadas = [];
    errores = 0;
    aciertos = 0

    $bienvenido.style.display = "none"
    if(palabras.length > 0){
        $contentGame.style.display = "flex" 
        $agregarPalabras.style.display = "none"
    }

    $letrasUtilizadas.textContent = ""
    $errores.textContent= ""
    $letrasADescubrir.textContent = ""
    $imagen.setAttribute("src",`img/ahorcado-${errores}.png`)

    const { children } = $teclado
    for (let i = 0; i < children.length; i++) {
            children[i].style.width = "3.75em"
            children[i].style.height = "3.75em"
            children[i].style.opacity = "1"
    }

    if (palabras.length === 0) {

        $contentGame.style.display = "none"
        $agregarPalabras.style.display = "flex"
        const agregarPalabra = (palabra) => {

            if(palabra === "") {

                return console.error("Debes ingresar algo");
            }
            else if(palabras.includes(palabra)){

                $error.innerText = "Esta palabra ya se encuentra en la lista"
                $input.value = ""
            }
            else if (!palabras.includes(palabra) && palabra !== undefined) {

                palabras.push(palabra)

                $input.value = ""
                $error.innerText = ""

                if (palabras.length > 0) {
                    $buttonVolverAJugar.addEventListener("click",start)
                }
            }     
        }
        const handleSubmit = (e) => {

            e.preventDefault()

            agregarPalabra($input.value.toUpperCase())
        }

        $formAgregarPalabras.addEventListener("submit",handleSubmit)
    }else{

        seleccionDeLaPalabra()

        pintarPalabra()

        document.addEventListener("keydown", handleKeydown)
    }
}


$buttonEmpezar.addEventListener("click", start)